import javafx.geometry.Insets;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import acsse.csc03a3.Block;
import acsse.csc03a3.Blockchain;
import acsse.csc03a3.Transaction;

/*@author TP MANYANYE 
 * @author Student Number: 221019983
 */

public class MedicalRecordData extends StackPane {
    private Stage primaryStage;
    private TextField idField;
    private TextField gField;
    private TextField patientNameField;
    private TextField ageField;
    private TextField diagnosisField;
    private TextField treatmentField;
    private TextField numberField;
    private TextField dateField;
    private TextField heightField; 
    private TextField weightField; 
    private TextField bloodTypeField; 
    private TextField allergiesField; 
    private TextField bloodPressureField; 
    private TextField cholesterolLevelField; 
    private TextField searchField;
    private Label searchLabel;
    
    private Button saveRecordButton;
    private Button updateRecordButton;
    private Button backButton;

    String previousHashvalue;

    private Block<String> block;
    private Blockchain<String> blockchain;
    private Dashboard dboard = new Dashboard();
    private List<Transaction<String>> listtransaction = new ArrayList<Transaction<String>>();

    public MedicalRecordData(Stage primaryStage, Blockchain<String> blockchain) {
        this.primaryStage = primaryStage;
        this.blockchain = blockchain;
        block = new Block<String>(previousHashvalue, listtransaction);
        
        //Initialize the search field and label
        searchLabel = new Label("Search Patient:");
        searchLabel.setTextFill(Color.WHITE);
        searchLabel.setFont(Font.font("Arial", 14));

       
       
        healthRecordViewerScreen();
    }

    public void healthRecordViewerScreen() {
        primaryStage.setTitle("Health Record Viewer");

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(50));
        gridPane.setVgap(10);
        gridPane.setHgap(10);
        gridPane.setAlignment(Pos.CENTER);

        // Adding Labels and TextFields to GridPane
        Label searchLabel = new Label("Search Patient:");
        gridPane.add(searchLabel, 0, 0); // Add search label at row 0, column 0

        searchField = new TextField();
        searchField.setPromptText("Enter patient name...");
        gridPane.add(searchField, 1, 0); // Add search field at row 0, column 1

        gridPane.add(new Label("ID:"), 0, 1);
        idField = new TextField();
        gridPane.add(idField, 1, 1);

        gridPane.add(new Label("Patient Name:"), 0, 2);
        patientNameField = new TextField();
        gridPane.add(patientNameField, 1, 2);

        gridPane.add(new Label("Gender:"), 0, 3);
        gField = new TextField();
        gridPane.add(gField, 1, 3);

        // Add other fields similarly...
        gridPane.add(new Label("Age:"), 0, 4);
        ageField = new TextField();
        gridPane.add(ageField, 1, 4);

        gridPane.add(new Label("Diagnosis:"), 0, 5);
        diagnosisField = new TextField();
        gridPane.add(diagnosisField, 1, 5);

        gridPane.add(new Label("Treatment:"), 0, 6);
        treatmentField = new TextField();
        gridPane.add(treatmentField, 1, 6);

        gridPane.add(new Label("Phone Number:"), 0, 7);
        numberField = new TextField();
        gridPane.add(numberField, 1, 7);

        gridPane.add(new Label("Height:"), 0, 8);
        heightField = new TextField();
        gridPane.add(heightField, 1, 8);

        gridPane.add(new Label("Weight:"), 0, 9);
        weightField = new TextField();
        gridPane.add(weightField, 1, 9);

        gridPane.add(new Label("Blood Type:"), 0, 10);
        bloodTypeField = new TextField();
        gridPane.add(bloodTypeField, 1, 10);

        gridPane.add(new Label("Allergies:"), 0, 11);
        allergiesField = new TextField();
        gridPane.add(allergiesField, 1, 11);

        gridPane.add(new Label("Blood Pressure:"), 0, 12);
        bloodPressureField = new TextField();
        gridPane.add(bloodPressureField, 1, 12);

        gridPane.add(new Label("Cholesterol Level:"), 0, 13);
        cholesterolLevelField = new TextField();
        gridPane.add(cholesterolLevelField, 1, 13);

        gridPane.add(new Label("Date:"), 0, 14);
        dateField = new TextField();
        gridPane.add(dateField, 1, 14);
        
        searchField.setOnKeyReleased(e -> {
            String searchName = searchField.getText().trim();
            if (!searchName.isEmpty()) {
               
                UserData userData = retrieveUserData(searchName);
                if (userData != null) {
                    fillInFields(userData);
                }
            }
        });

        // Adding Buttons
        saveRecordButton = new Button("Save Medical Record");
        saveRecordButton.setOnAction(e -> {
            if (blockchain != null) {
                saveMedicalRecord();
            } else {
                showAlert("Error", "Blockchain is not initialized.");
            }
        });

        updateRecordButton = new Button("Update Medical Record");
        updateRecordButton.setOnAction(e -> {
            if (blockchain != null) {
                updateMedicalRecord();
            } else {
                showAlert("Error", "Blockchain is not initialized.");
            }
        });

        backButton = new Button("Back to Dashboard");
        backButton.setOnAction(e -> {
            dboard.dashboardScreen(primaryStage, blockchain);
        });

        gridPane.add(saveRecordButton, 0, 15);
        gridPane.add(updateRecordButton, 1, 15);
        gridPane.add(backButton, 0, 16, 2, 1); // Merge cells for the back button

        // Set background color
        gridPane.setStyle("-fx-background-color: #34495E;");

        Scene scene = new Scene(gridPane, 800, 800);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    

    public void fillInFields(UserData userData) {
        // Fill in the input fields with the retrieved data
        idField.setText(userData.getId());
        gField.setText(userData.getGender());
        patientNameField.setText(userData.getName());
        ageField.setText(userData.getAge());
        diagnosisField.setText(userData.getDiagnosis());
        treatmentField.setText(userData.getTreatment());
        numberField.setText(userData.getPhoneNumber());
        
        heightField.setText(userData.getHeight());
        weightField.setText(userData.getWeight());
        bloodTypeField.setText(userData.getBloodType());
        allergiesField.setText(userData.getAllergies());
        bloodPressureField.setText(userData.getBloodPressure());
        cholesterolLevelField.setText(userData.getCholesterolLevel());
        dateField.setText(userData.getDate());
    }

    private void saveMedicalRecord() {
        // Validate input fields
        String identity = idField.getText();
        String pname = patientNameField.getText();
        String gender = gField.getText();
        String age = ageField.getText();
        String diagnosis = diagnosisField.getText();
        String treatment = treatmentField.getText();
        String number = numberField.getText();
        String height = heightField.getText();
        String weight = weightField.getText();
        String bloodType = bloodTypeField.getText();
        String allergies = allergiesField.getText();
        String bloodPressure = bloodPressureField.getText();
        String cholesterolLevel = cholesterolLevelField.getText();
        String date = dateField.getText();

        if (identity.isEmpty() || pname.isEmpty() || gender.isEmpty() || age.isEmpty() || diagnosis.isEmpty()
                || treatment.isEmpty() || number.isEmpty() || height.isEmpty() || weight.isEmpty()
                || bloodType.isEmpty() || allergies.isEmpty()  || bloodPressure.isEmpty()
                || cholesterolLevel.isEmpty()|| date.isEmpty()) {
            showAlert("Error", "Please fill in all fields.");
            return;
        }

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "root",
                "")) {
            // Check if the record already exists
            UserData existingData = retrieveUserData(pname);
            if (existingData != null) {
                showAlert("Error", "A medical record already exists for this patient. Please use the update button.");
            } else {
                // Insert a new record
                insertMedicalRecord(connection, identity, pname, gender, age, diagnosis, treatment, number, height,
                        weight, bloodType, allergies, bloodPressure, cholesterolLevel, date);
                // After saving the medical record, create a transaction and add it to the
                // blockchain
                String data = "Patient Name: " + pname + ", Gender: " + gender + ", Age: " + age
                        + ", Diagnosis: " + diagnosis + ", Treatment: " + treatment + ", Phone Number: " + number
                        + ", Height: " + height + ", Weight: " + weight + ", Blood Type: " + bloodType
                        + ", Allergies: " + allergies + ", Blood Pressure: " + bloodPressure + ", Cholesterol Level: "
                        + cholesterolLevel + ", Date: " + date;
                Transaction<String> transaction = new Transaction<>("Sender", "Receiver", data);
                addTransactionToBlockchain(transaction);
                showAlert("Success", "New medical record has been saved successfully!");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            showAlert("Error", "An error occurred while saving the medical record.");
        }
    }

    private void updateMedicalRecord() {
        // Validate input fields
        String identity = idField.getText();
        String pname = patientNameField.getText();
        String gender = gField.getText();
        String age = ageField.getText();
        String diagnosis = diagnosisField.getText();
        String treatment = treatmentField.getText();
        String number = numberField.getText();
        String height = heightField.getText();
        String weight = weightField.getText();
        String bloodType = bloodTypeField.getText();
        String allergies = allergiesField.getText();
        String bloodPressure = bloodPressureField.getText();
        String cholesterolLevel = cholesterolLevelField.getText();
        String date = dateField.getText();

        if (identity.isEmpty() || pname.isEmpty() || gender.isEmpty() || age.isEmpty() || diagnosis.isEmpty()
                || treatment.isEmpty() || number.isEmpty() || height.isEmpty() || weight.isEmpty()
                || bloodType.isEmpty() || allergies.isEmpty()  || bloodPressure.isEmpty()
                || cholesterolLevel.isEmpty()|| date.isEmpty()) {
            showAlert("Error", "Please fill in all fields.");
            return;
        }

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "root",
                "")) {
            // Check if the record already exists
            UserData existingData = retrieveUserData(pname);
            if (existingData == null) {
                showAlert("Error", "No medical record found for this patient. Please use the save button.");
            } else {
                // Update the existing record
                updateMedicalRecord(connection, identity, pname, gender, age, diagnosis, treatment, number, height,
                        weight, bloodType, allergies, bloodPressure, cholesterolLevel, date);
                // After updating the medical record, create a transaction and add it to the
                // blockchain
                String data = "Patient Name: " + pname + ", Gender: " + gender + ", Age: " + age
                        + ", Diagnosis: " + diagnosis + ", Treatment: " + treatment + ", Phone Number: " + number
                        + ", Height: " + height + ", Weight: " + weight + ", Blood Type: " + bloodType
                        + ", Allergies: " + allergies + ", Blood Pressure: " + bloodPressure + ", Cholesterol Level: "
                        + cholesterolLevel + ", Date: " + date;
                Transaction<String> transaction = new Transaction<>(pname, "Receiver", data);
                addTransactionToBlockchain(transaction);
                showAlert("Success", "Medical record has been updated successfully!");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            showAlert("Error", "An error occurred while updating the medical record.");
        }
    }

    public void addTransactionToBlockchain(Transaction<String> transaction) {
        // Encrypt the data before adding it to the block
        String encryptedData = encryptData(transaction.getData());
        transaction.setData(encryptedData);

        listtransaction.add(transaction);
        block = new Block<>(block.getHash(), listtransaction);
        block.setNonce(hashCode());
        String selectedValidator = block.getPreviousHash();
        Random rand = new Random();
        blockchain.registerStake(selectedValidator, rand.nextInt(101));
        blockchain.addBlock(listtransaction);
        boolean isChainValid = blockchain.isChainValid();
        System.out.println("Chain Validity: " + isChainValid);
        System.out.println("Added block: " + block); // Print out the added block
        
        
        
    }

    private String encryptData(String data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(data.getBytes());
            byte[] digest = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    private void insertMedicalRecord(Connection connection, String identity, String pname, String gender, String age,
            String diagnosis, String treatment, String number, String height, String weight, String bloodType,
            String allergies, String bloodPressure, String cholesterolLevel, String date) throws SQLException {
        // SQL query to insert user data into the database
        String sql = "INSERT INTO board (`ID`, `Patient Name`, `Gender`, `Age`, `Diagnosis`, `Treatment`, `Phone Number`, `Height`, `Weight`, `Blood Type`, `Allergies`, `Blood Pressure`, `Cholesterol Level`, `Date`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            // Set parameters for the prepared statement
            statement.setString(1, identity);
            statement.setString(2, pname);
            statement.setString(3, gender);
            statement.setString(4, age);
            statement.setString(5, diagnosis);
            statement.setString(6, treatment);
            statement.setString(7, number);
            statement.setString(8, height);
            statement.setString(9, weight);
            statement.setString(10, bloodType);
            statement.setString(11, allergies);
            statement.setString(12, bloodPressure);
            statement.setString(13, cholesterolLevel);
            statement.setString(14, date);

            // Execute the statement
            statement.executeUpdate();
        }
    }

    private void updateMedicalRecord(Connection connection, String identity, String pname, String gender, String age,
            String diagnosis, String treatment, String number, String height, String weight, String bloodType,
			String allergies, String bloodPressure, String cholesterolLevel, String date) throws SQLException {
        // SQL query to update user data in the database
        String sql = "UPDATE board SET `ID`=?, `Patient Name`=?, `Gender`=?, `Age`=?, `Diagnosis`=?, `Treatment`=?, `Phone Number`=?, `Height`=?, `Weight`=?, `Blood Type`=?, `Allergies`=?, `Blood Pressure`=?, `Cholesterol Level`=?, `Date`=? WHERE `Patient Name`=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            // Set parameters for the prepared statement
            statement.setString(1, identity);
            statement.setString(2, pname);
            statement.setString(3, gender);
            statement.setString(4, age);
            statement.setString(5, diagnosis);
            statement.setString(6, treatment);
            statement.setString(7, number);
            statement.setString(8, height);
            statement.setString(9, weight);
            statement.setString(10, bloodType);
            statement.setString(11, allergies);
            statement.setString(12, bloodPressure);
            statement.setString(13, cholesterolLevel);
            statement.setString(14, date);
            statement.setString(15, pname); // Where clause value

            // Execute the statement
            statement.executeUpdate();
        }
    }

    public UserData retrieveUserData(String searchName) {
        // Retrieve user data from the database based on the searchName
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "root", "")) {
            String sql = "SELECT * FROM board WHERE `Patient Name` = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, searchName);
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        return new UserData(
                                resultSet.getString("ID"),
                                resultSet.getString("Gender"),
                                resultSet.getString("Patient Name"),
                                resultSet.getString("Age"),
                                resultSet.getString("Diagnosis"),
                                resultSet.getString("Treatment"),
                                resultSet.getString("Phone Number"),
                                resultSet.getString("Height"),
                                resultSet.getString("Weight"),
                                resultSet.getString("Blood Type"),
                                resultSet.getString("Allergies"),
                                resultSet.getString("Blood Pressure"),
                                resultSet.getString("Cholesterol Level"),
                                resultSet.getString("Date")
                        );
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

//   

    public void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
