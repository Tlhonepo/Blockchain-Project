import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class PatientDataAnalysis extends Application {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/mydatabase";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";
    private Stage primaryStage;
    private ComboBox<String> medicalRecordComboBox;

    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;

        VBox root = new VBox(10);
        root.setPadding(new Insets(10));

        Label searchLabel = new Label("Search Patient Name:");
        TextField searchField = new TextField();
        searchField.setPromptText("Enter patient name to search");

        HBox searchBox = new HBox(5);
        searchBox.getChildren().addAll(searchLabel, searchField);

        medicalRecordComboBox = new ComboBox<>();
        medicalRecordComboBox.setEditable(true);
        medicalRecordComboBox.setPromptText("Select or Search Patient Name");

        populateMedicalRecords(medicalRecordComboBox);

        Button analyzeDataButton = new Button("Analyze Patient Data");
        analyzeDataButton.setOnAction(event -> {
            String selectedPatient = medicalRecordComboBox.getValue();
            if (selectedPatient != null && !selectedPatient.isEmpty()) {
                analyzeData(selectedPatient);
            } else {
                showAlert("Error", "Please select a patient to analyze.");
            }
        });

        root.getChildren().addAll(searchBox, medicalRecordComboBox, analyzeDataButton);

        Scene scene = new Scene(root, 400, 200);
        primaryStage.setTitle("Patient Data Analysis");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void populateMedicalRecords(ComboBox<String> medicalRecordComboBox) {
        ObservableList<String> records = FXCollections.observableArrayList();
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT DISTINCT `Patient Name` FROM board";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        records.add(resultSet.getString("Patient Name"));
                    }
                }
            }
        } catch (SQLException ex) {
            handleSQLException(ex, "Error fetching medical records from the database.");
        }
        medicalRecordComboBox.setItems(records);
    }

    private void analyzeData(String username) {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            Map<String, Double> measurements = analyzePatientData(connection, username);
            BarChart<String, Number> barChart = displayBarChart(username, measurements);
            displayPieCharts(username, connection, barChart);
        } catch (SQLException ex) {
            handleSQLException(ex, "Error analyzing patient data.");
        }
    }

    private Map<String, Double> analyzePatientData(Connection connection, String username) throws SQLException {
        Map<String, Double> measurements = new HashMap<>();

        String sql = "SELECT CAST(SUBSTRING_INDEX(Weight, ' ', 1) AS DECIMAL) AS Weight, " +
                     "CAST(SUBSTRING_INDEX(`Blood Pressure`, ' ', 1) AS DECIMAL) AS BloodPressure, " +
                     "CAST(SUBSTRING_INDEX(`Cholesterol Level`, ' ', 1) AS DECIMAL) AS CholesterolLevel " +
                     "FROM board WHERE `Patient Name` = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, username);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    double weight = resultSet.getDouble("Weight");
                    double bloodPressure = resultSet.getDouble("BloodPressure");
                    double cholesterol = resultSet.getDouble("CholesterolLevel");

                    measurements.put("Weight", weight);
                    measurements.put("Blood Pressure", bloodPressure);
                    measurements.put("Cholesterol Level", cholesterol);
                }
            }
        }
        return measurements;
    }

    private BarChart<String, Number> displayBarChart(String username, Map<String, Double> measurements) {
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle("Measurements for " + username);
        xAxis.setLabel("Measurement");
        yAxis.setLabel("Value");

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Measurements");

        for (Map.Entry<String, Double> entry : measurements.entrySet()) {
            series.getData().add(new XYChart.Data<>(entry.getKey(), entry.getValue()));
        }

        barChart.getData().add(series);

        return barChart;
    }

    private void displayPieCharts(String username, Connection connection, BarChart<String, Number> barChart) {
        VBox pieChartsBox = new VBox(20);

        try {
            PieChart commonDiagnosesChart = createPieChart("Diagnoses", connection, "Diagnosis", username);
            PieChart commonTreatmentsChart = createPieChart("Treatments", connection, "Treatment", username);

            pieChartsBox.getChildren().addAll(commonDiagnosesChart, commonTreatmentsChart);
        } catch (SQLException ex) {
            handleSQLException(ex, "Error creating pie charts.");
        }

        GridPane gridPane = new GridPane();
        gridPane.add(barChart, 0, 0);
        gridPane.add(pieChartsBox, 1, 0);

        Scene scene = new Scene(gridPane, 1200, 600);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Analysis Chart");
        primaryStage.show();
    }

    private PieChart createPieChart(String title, Connection connection, String column, String username) throws SQLException {
        PieChart pieChart = new PieChart();
        pieChart.setTitle(title);

        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
        String sql = "SELECT " + column + ", COUNT(*) AS count FROM board WHERE `Patient Name` = ? GROUP BY " + column;
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, username);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    String label = resultSet.getString(column);
                    int count = resultSet.getInt("count");
                    pieChartData.add(new PieChart.Data(label, count));
                }
            }
        }

        pieChart.setData(pieChartData);
        return pieChart;
    }

    private void handleSQLException(SQLException ex, String message) {
        ex.printStackTrace();
        showAlert("Error", message);
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

   
}
