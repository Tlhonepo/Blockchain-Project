import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.security.MessageDigest; // for password encryption
import java.security.NoSuchAlgorithmException; // for password encryption
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import acsse.csc03a3.Block;
import acsse.csc03a3.Blockchain;
import acsse.csc03a3.Transaction;
/*@author TP MANYANYE 
 * @author Student Number: 221019983
 */
public class RegistrationPane<T> extends StackPane {
	private Stage primaryStage;
	private TextField usernameField = new TextField();
	private TextField emailField = new TextField();
	private TextField passwordField = new TextField();
	private Button registerButton = new Button("Register");
	private boolean isAlreadyRegisteredClicked = false;
	Block<String> block;
	Blockchain<String> blockchain;

	Transaction<String> transaction;
	String previousHashValue;
	LoginPane loginPane = new LoginPane();
	List<Transaction<String>> listtransaction = new ArrayList<Transaction<String>>();

	public RegistrationPane(Stage primaryStage, Blockchain<String> blockchain) {

		this.primaryStage = primaryStage;
		this.blockchain = blockchain;
		registerButton.setOnAction(e -> {
			isAlreadyRegisteredClicked = true;
			registerUser();
			redirectToLogin();
		});

		block = new Block<String>(previousHashValue, listtransaction);

	}

	public void registrationScreen() {
		primaryStage.setTitle("Registration");

		ImageView logoImageView = new ImageView(new Image("logo.jpg"));
		logoImageView.setFitWidth(150);
		logoImageView.setFitHeight(150);

		Label sloganLabel = new Label("The safety of your health is in our hands!");
		sloganLabel.setFont(Font.font("Arial", 16));
		sloganLabel.setTextFill(Color.WHITE);

		Label titleLabel = new Label("Registration");
		titleLabel.setFont(Font.font("Arial", 24));
		titleLabel.setTextFill(Color.WHITE);

		VBox registrationLayout = new VBox(20);
		registrationLayout.setAlignment(Pos.CENTER);
		registrationLayout.setPadding(new Insets(50));
		registrationLayout.setStyle("-fx-background-color: #001f3f; -fx-text-fill: white;");

		HBox logoPane = new HBox();
		logoPane.setAlignment(Pos.CENTER);
		HBox.setHgrow(logoPane, Priority.ALWAYS);
		logoPane.getChildren().addAll(logoImageView);

		registrationLayout.getChildren().addAll(sloganLabel, titleLabel, logoPane,
				createLabeledTextField("Username:", usernameField), createLabeledTextField("Password:", passwordField),
				createLabeledTextField("Email:", emailField));

		HBox bottomContainer = new HBox(20);
		bottomContainer.setAlignment(Pos.CENTER);
		bottomContainer.getChildren().addAll(registerButton, createLoginHyperlink());

		BorderPane borderPane = new BorderPane();
		borderPane.setCenter(registrationLayout);
		borderPane.setBottom(bottomContainer);

		Scene scene = new Scene(borderPane);
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	private HBox createLabeledTextField(String labelText, TextField textField) {
		Label label = new Label(labelText);
		label.setTextFill(Color.WHITE);
		label.setFont(Font.font("Arial", 14));
		HBox labeledTextField = new HBox(20);
		labeledTextField.getChildren().addAll(label, textField);
		labeledTextField.setAlignment(Pos.CENTER);
		return labeledTextField;
	}

	private Hyperlink createLoginHyperlink() {
		Hyperlink loginLink = new Hyperlink("Already registered? Login here");
		loginLink.setTextFill(Color.BLUE);
		loginLink.setOnAction(e -> redirectToLogin());
		return loginLink;
	}

	@SuppressWarnings("unchecked")
	private void redirectToLogin() {


		isAlreadyRegisteredClicked = true;
		// This loginPane object creation is missing, assuming it's defined elsewhere
		loginPane.loginScreen(primaryStage, blockchain);

	}

	private void registerUser() {
		String username = usernameField.getText();
		String email = emailField.getText();
		String password = passwordField.getText();

		if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
			showAlert("Error", "Please fill in all fields.");
			return;
		}

		// Check if the user already exists in the database
		try (Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "root", "");
				PreparedStatement checkIfExistsStatement = connect
						.prepareStatement("SELECT * FROM regboard WHERE Email=?")) {

			checkIfExistsStatement.setString(1, email);
			ResultSet existingUserResult = checkIfExistsStatement.executeQuery();

			if (existingUserResult.next()) {
				showAlert("Error", "User with this email already exists.");
				return;
			}

			// Insert the user into the database with plain text password
			String sql = "INSERT INTO regboard (Username, Email, Password) VALUES (?, ?, ?)";
			try (PreparedStatement statement = connect.prepareStatement(sql)) {
				statement.setString(1, username);
				statement.setString(2, email);
				statement.setString(3, password);

				int rowsAffected = statement.executeUpdate();

				if (rowsAffected > 0) {
					// User registered successfully, create transaction and add to blockchain
					showAlert("Success", "User registered successfully!");

					String data = "Username: " + username + ", Email: " + email;
					Transaction<String> transaction = new Transaction<>(username, email, data);
					addTransactionToBlockchain(transaction);

					// Print out the block after successful registration
					System.out.println("Block after user registration: " + block);

					redirectToLogin(); // Redirect after successful registration
				} else {
					showAlert("Error", "Failed to register user. Please try again.");
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			showAlert("Error", "Failed to register user. Please try again later.");
		}
	}

	private String encryptPassword(String password) {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			md.update(password.getBytes());
			byte[] digest = md.digest();
			StringBuilder sb = new StringBuilder();
			for (byte b : digest) {
				sb.append(String.format("%02x", b));
			}
			return sb.toString();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return null;
		}
	}

	public void addTransactionToBlockchain(Transaction<String> transaction) {
		List<Transaction<String>> listTransaction = new ArrayList<>(); // Initialize listTransaction
		// Create an instance of your blockchain
		listTransaction.add(transaction);

		// Encrypt the password before adding it to the block
		String encryptedPassword = encryptPassword(transaction.getData());
		transaction.setData("Username: " + transaction.getSender() + ", Password: " + encryptedPassword + ", Email: "
				+ transaction.getReceiver());

		block = new Block<>(block.getHash(), listTransaction); // = new Block<>(previousHash, listTransaction);
		block.setNonce(hashCode());
		String selectedValidator = block.getPreviousHash();
		Random rand = new Random();
		blockchain.registerStake(selectedValidator, rand.nextInt(101)); // Register stake
		blockchain.addBlock(listTransaction);
		boolean isChainValid = blockchain.isChainValid(); // Check validity of the chain
		System.out.println("Chain Validity: " + isChainValid);
		System.out.println("Added block: " + block);
	}

	public static void showAlert(String title, String message) {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		alert.showAndWait();
	}
}
