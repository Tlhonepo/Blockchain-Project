import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import acsse.csc03a3.Block;
import acsse.csc03a3.Blockchain;
import acsse.csc03a3.Transaction;


/*@author TP MANYANYE 
 * @author Student Number: 221019983
 */
public class Dashboard extends StackPane {
    private String patientName;
    private String doctorName;
    private String medicationInfo;
    private Stage primaryStage;
    private DoctorRegistrationPane doctorRegistrationPane;
    private Blockchain<String> blockchain;
    String previousHashvalue;
    Block<String> block;
    private List<Transaction<String>> listtransaction = new ArrayList<>();

    public void dashboardScreen(Stage primaryStage, Blockchain<String> blockchain) {
        this.primaryStage = primaryStage;
        this.blockchain = blockchain;
        block = new Block<String>(previousHashvalue, listtransaction);
        doctorRegistrationPane = new DoctorRegistrationPane(primaryStage, blockchain);

        primaryStage.setTitle("Dashboard");

        // Dashboard Components
        Label dashboardLabel = new Label("Welcome to the Dashboard");
        dashboardLabel.setFont(Font.font("Arial", 20));

        Button healthRecordViewerButton = createStyledButton("Health Record Viewer");
        Button dataSharingAgreementButton = createStyledButton("Data Sharing Agreement");
        Button authorizedDocButton = createStyledButton("Authorized Doctors");
        Button logoutButton = createStyledButton("Logout");
        Button analyzeDataButton = createStyledButton("Analyze Patient Data");

        ImageView logoImageView = new ImageView(new Image("logo.jpg"));
        logoImageView.setFitWidth(200);
        logoImageView.setPreserveRatio(true);

        HBox logoPane = new HBox(logoImageView);
        logoPane.setAlignment(Pos.CENTER);

        VBox dashboardLayout = new VBox(20, logoPane, dashboardLabel, healthRecordViewerButton,
                dataSharingAgreementButton, authorizedDocButton, analyzeDataButton, logoutButton);
        dashboardLayout.setAlignment(Pos.CENTER);
        dashboardLayout.setPadding(new Insets(50));
        dashboardLayout.setStyle("-fx-background-color: #f0f0f0;");

        // Button Actions
        healthRecordViewerButton.setOnAction(e -> {
            MedicalRecordData medicalRecordData = new MedicalRecordData(primaryStage, blockchain);
            medicalRecordData.healthRecordViewerScreen();
        });
        dataSharingAgreementButton.setOnAction(e -> {
            
        	MedicalRecordTransaction mediTrans = new MedicalRecordTransaction(primaryStage, blockchain, patientName,
                    doctorName);
            mediTrans.dataSharingAgreementScreen();
        });
        authorizedDocButton.setOnAction(e -> {
            Scene doctorRegistrationScene = new Scene(doctorRegistrationPane, 600, 400);
            primaryStage.setScene(doctorRegistrationScene);
        });
        analyzeDataButton.setOnAction(event -> {
            PatientDataAnalysis patientDataAnalysis = new PatientDataAnalysis();
            Stage stage = new Stage();
            patientDataAnalysis.start(stage);
        });

        logoutButton.setOnAction(e -> {
            System.out.println("Logout action performed");
            primaryStage.close();
        });

        Scene dashboardScene = new Scene(dashboardLayout, 600, 500);
        primaryStage.setScene(dashboardScene);
    }

    private Button createStyledButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: #3498db; -fx-text-fill: white;");
        button.setPrefWidth(200);
        button.setPrefHeight(40);
        return button;
    }
}
