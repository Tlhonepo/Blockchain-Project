import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.*;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.List;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import acsse.csc03a3.Block;
import acsse.csc03a3.Blockchain;
import acsse.csc03a3.Transaction;
/*@author TP MANYANYE 
 * @author Student Number: 221019983
 */
public class MedicalRecordTransaction extends StackPane {
    private Stage primaryStage;

    private String patientName;
    private String doctorName;
    private Blockchain<String> blockchain;
    String previousHashvalue;
    private Dashboard dboard = new Dashboard();
    Block<String> block;
    private List<Transaction<String>> listtransaction = new ArrayList<>();

    public MedicalRecordTransaction(Stage primaryStage, Blockchain<String> blockchain, String patientName, String doctorName) {
        this.primaryStage = primaryStage;
        this.patientName = patientName;
        this.doctorName = doctorName;
        if (blockchain == null) {
            showAlert("Error", "Blockchain is not initialized.");
            
            return;
        }
        this.blockchain = blockchain;
        block = new Block<String>(previousHashvalue, listtransaction);
        dataSharingAgreementScreen();
    }

    public void dataSharingAgreementScreen() {
        primaryStage.setTitle("Data Sharing Agreement");

        Label dataSharingLabel = new Label("Create and Manage Data Sharing Agreements");
        dataSharingLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        ComboBox<String> medicalRecordComboBox = new ComboBox<>();
        medicalRecordComboBox.setPromptText("Search for a patient...");
        medicalRecordComboBox.setStyle("-fx-pref-width: 200px;");

        populateMedicalRecords(medicalRecordComboBox);

        ComboBox<String> doctorComboBox = new ComboBox<>();
        doctorComboBox.setPromptText("Search for a doctor...");
        doctorComboBox.setStyle("-fx-pref-width: 200px;");

        populateDoctors(doctorComboBox);

        Button shareDataButton = new Button("Share Medical Record");
        shareDataButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        shareDataButton.setOnAction(e -> shareMedicalRecord(medicalRecordComboBox.getValue(), doctorComboBox.getValue()));

        Button backButton = new Button("Back to Dashboard");
        backButton.setOnAction(e -> {
            // Call the method to display the dashboard scene
            dboard.dashboardScreen(primaryStage, blockchain);
        });

        VBox dataSharingLayout = new VBox(20, dataSharingLabel, medicalRecordComboBox, doctorComboBox,
                shareDataButton, backButton);
        dataSharingLayout.setAlignment(Pos.CENTER);
        dataSharingLayout.setPadding(new Insets(50));
        dataSharingLayout.setStyle("-fx-background-color: #f0f0f0;");

        Scene scene = new Scene(dataSharingLayout, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void populateMedicalRecords(ComboBox<String> medicalRecordComboBox) {
        ObservableList<String> records = FXCollections.observableArrayList();
        records.addAll(retrievePatientsFromDatabase());
        medicalRecordComboBox.setItems(records);
        medicalRecordComboBox.setOnAction(event -> showUserInfo(medicalRecordComboBox.getValue()));
    }

    private Collection<String> retrievePatientsFromDatabase() {
        Collection<String> patients = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "root", "")) {
            String sql = "SELECT `Patient Name` FROM board"; // Adjust table name as per your database schema
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        patients.add(resultSet.getString("Patient Name"));
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            showAlert("Error", "An error occurred while fetching patients from the database.");
        }
        return patients;
    }

    private void populateDoctors(ComboBox<String> doctorComboBox) {
        ObservableList<String> doctors = FXCollections.observableArrayList();
        doctors.addAll(retrieveDoctorsFromDatabase());
        doctorComboBox.setItems(doctors);
        doctorComboBox.setOnAction(event -> showDoctorInformation(doctorComboBox.getValue()));
    }

    private void shareMedicalRecord(String selectedRecord, String selectedDoctor) {
        if (selectedRecord != null && selectedDoctor != null) {
            try {
                // Establish connection to the database
                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "root", "");

                // Retrieve patient record from the database
                String patientRecord = retrievePatientRecord(connection, selectedRecord);

                if (!patientRecord.equals("Patient record not found")) {
                    // Sharing logic
                    String notificationMessage = "Medical record \"" + selectedRecord + "\" shared with Doctor \"" + selectedDoctor + "\"";
                    showConfirmationMessage(notificationMessage);

                    // Add transaction to blockchain
                    String data = "Patient Name: " + selectedRecord + ", Doctor Name: " + selectedDoctor + ", Patient Record: " + patientRecord;
                    Transaction<String> transaction = new Transaction<>(selectedRecord, selectedDoctor,data);
                    addTransactionToBlockchain(transaction);
                } else {
                    showError("Selected patient record not found in the database.");
                }

                // Close database connection
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
                showError("Error occurred while retrieving or sharing medical record.");
            }
        } else {
            showError("Please select both a medical record and a doctor to share with.");
        }
    }




    // Method to retrieve patient record from the database
    private String retrievePatientRecord(Connection connection, String selectedRecord) throws SQLException {
    	 String sql = "SELECT * FROM board WHERE `Patient Name` = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, selectedRecord);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            String pname = resultSet.getString("Patient Name");
            String gender = resultSet.getString("Gender");
            int age = resultSet.getInt("Age");
            String diagnosis = resultSet.getString("Diagnosis");
            String treatment = resultSet.getString("Treatment");
            String number = resultSet.getString("Phone Number");
            String height = resultSet.getString("Height");
            String weight = resultSet.getString("Weight");
            String bloodType = resultSet.getString("Blood Type");
            String allergies = resultSet.getString("Allergies");
            String bloodPre = resultSet.getString("Blood Pressure");

            return "Patient Name: " + pname + "\n" +
            "Gender: " + gender + "\n" +
            "Age: " + age + "\n" +
            "Diagnosis: " + diagnosis + "\n" +
            "Treatment: " + treatment + "\n" +
            "Phone Number: " + number + "\n" +
            "Height: " + height + "\n" +
            "Weight: " + weight + "\n" +
            "Blood Type: " + bloodType + "\n" +
            "Allergies: " + allergies + "\n" +
            "Blood Pressure: " + bloodPre;

        } else {
            return "Patient record not found";
        }
    }

    private Collection<String> retrieveDoctorsFromDatabase() {
        Collection<String> doctors = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "root", "")) {
            String sql = "SELECT `Username` FROM authorized_doctors"; // Adjust table name as per your database schema
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        doctors.add(resultSet.getString("Username"));
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            showAlert("Error", "An error occurred while fetching doctors from the database.");
        }
        return doctors;
    }

    private void showUserInfo(String username) {
        StringBuilder userInfo = new StringBuilder();
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "root", "")) {
            String sql = "SELECT * FROM board WHERE `Patient Name` = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, username);
                try (ResultSet resultSet = statement.executeQuery()) {
                    ResultSetMetaData metaData = resultSet.getMetaData();
                    int columnCount = metaData.getColumnCount();
                    if (resultSet.next()) {
                        for (int i = 1; i <= columnCount; i++) {
                            userInfo.append(metaData.getColumnLabel(i)).append(": ")
                                    .append(resultSet.getString(i)).append("\n");
                        }
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            showAlert("Error", "An error occurred while fetching user information from the database.");
            return;
        }
        // Display user information in an alert box
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("User Information");
        alert.setHeaderText("Information for user: " + username);
        alert.setContentText(userInfo.toString());
        alert.showAndWait();
    }

    private void showDoctorInformation(String username) {
        StringBuilder doctorInfo = new StringBuilder();
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "root", "")) {
            String sql = "SELECT * FROM authorized_doctors WHERE `Username` = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, username);
                try (ResultSet resultSet = statement.executeQuery()) {
                    ResultSetMetaData metaData = resultSet.getMetaData();
                    int columnCount = metaData.getColumnCount();
                    if (resultSet.next()) {
                        for (int i = 1; i <= columnCount; i++) {
                            doctorInfo.append(metaData.getColumnLabel(i)).append(": ")
                                    .append(resultSet.getString(i)).append("\n");
                        }
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            showAlert("Error", "An error occurred while fetching doctor information from the database.");
            return;
        }
        // Display doctor information in an alert box
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Doctor Information");
        alert.setHeaderText("Information for doctor: " + username);
        alert.setContentText(doctorInfo.toString());
        alert.showAndWait();
    }

    public void addTransactionToBlockchain(Transaction<String> transaction) {

    	// Encrypt the data before adding it to the block
        try {
            if (blockchain == null) {
                showAlert("Error", "Blockchain is not initialized.");
                return;
            }

            // Convert transaction data to bytes
            byte[] transactionData = transaction.getData().getBytes();

            // Generate a secret key
            SecretKey secretKey = generateSecretKey();

            // Encrypt the transaction data using the secret key
            byte[] encryptedData = encrypt(transactionData, secretKey);

            // Convert encrypted data to a String (for demonstration purposes)
            String encryptedDataString = Base64.getEncoder().encodeToString(encryptedData);

            // Add the encrypted data to the block
            listtransaction.add(new Transaction<String>(encryptedDataString, encryptedDataString, encryptedDataString));

            block = new Block<>(block.calculateHash(), listtransaction);
            block.setNonce(hashCode());

            String selectedValidator = block.getPreviousHash();
            Random rand = new Random();
            blockchain.registerStake(selectedValidator, rand.nextInt(101));
            blockchain.addBlock(listtransaction);

            boolean isChainValid = blockchain.isChainValid();
            System.out.println("Chain Validity: " + isChainValid);
            System.out.println("Added block: " + block); // Print out the added block

            saveTransactionToDatabase(block.toString()); // Save the block to the database

        } catch (Exception e) {
            e.printStackTrace();
            // Handle encryption or other exceptions
        }
    }

    // Method to generate a secret key
    private SecretKey generateSecretKey() throws Exception {
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(128); // You can change this to 256 for stronger encryption
        return keyGen.generateKey();
    }

    // Method to encrypt data using AES with a secret key
    private byte[] encrypt(byte[] data, SecretKey key) throws Exception {
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        return cipher.doFinal(data);
    }

    private void saveTransactionToDatabase(String transactionData) {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "root", "")) {
            String insertTransactionQuery = "INSERT INTO blockchain (Transactions) VALUES (?)";
            try (PreparedStatement insertStatement = connection.prepareStatement(insertTransactionQuery)) {
                insertStatement.setString(1, transactionData);
                insertStatement.executeUpdate();
                System.out.println("Saved to database blockchain");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            showAlert("Error", "An error occurred while saving transaction to the database.");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        //alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showConfirmationMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Record Shared");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
