import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import acsse.csc03a3.Block;
import acsse.csc03a3.Blockchain;
import acsse.csc03a3.Transaction;


/*@author TP MANYANYE 
 * @author Student Number: 221019983
 */
public class LoginPane extends StackPane {
	
    private Blockchain<String> blockchain;
    String previousHashvalue;
    Block<String> block;
    private List<Transaction<String>> listtransaction = new ArrayList<>();
    

	public void loginScreen(Stage primaryStage, Blockchain<String> blockchain) {
		this.blockchain = blockchain;
        block = new Block<String>(previousHashvalue, listtransaction);
		primaryStage.setTitle("HealthCare Data-Exchange Application - Login");

		// Create login components
		TextField usernameField = new TextField();
		PasswordField passwordField = new PasswordField();
		CheckBox rememberMeCheckbox = new CheckBox("Remember Me");
		Button loginButton = new Button("Login");

		loginButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;"); // Green button style

		loginButton.setOnAction(e -> {
			String username = usernameField.getText();
			String password = passwordField.getText();

			// Connect to the database and authenticate the user
			try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "root",	"")) 
				
			{
				String sql = "SELECT Password FROM regboard WHERE Username = ?";
				try (PreparedStatement statement = connection.prepareStatement(sql)) {
					statement.setString(1, username);
					ResultSet resultSet = statement.executeQuery();
					if (resultSet.next()) {
						String storedPassword = resultSet.getString("Password");
						if (password.equals(storedPassword)) {
							// Passwords match, allow the user to log in
							Dashboard dashboard = new Dashboard();
							dashboard.dashboardScreen(primaryStage, blockchain);
							return;
						}
					}
				}
			} catch (SQLException ex) {
				ex.printStackTrace();
			}

			// If authentication fails, display an error message
			System.out.println("Login failed. Please enter valid credentials.");
		});

		// Add health cross logo at the top and center
		ImageView logoImageView = new ImageView(new Image("logo.jpg"));

		logoImageView.setFitWidth(150);
		logoImageView.setFitHeight(150);

		// Add the slogan above the logo
		Label sloganLabel = new Label("The safety of your health is in our hands!");
		sloganLabel.setFont(Font.font("Arial", 16));
		sloganLabel.setTextFill(Color.WHITE); // Set text color to white

		// Title for login screen
		Label titleLabel = new Label("Login");
		titleLabel.setFont(Font.font("Arial", 24));
		titleLabel.setTextFill(Color.WHITE); // Set text color to white

		VBox loginLayout = new VBox(20);
		loginLayout.setAlignment(Pos.CENTER); // Center the content
		loginLayout.setPadding(new Insets(50));
		loginLayout.setStyle("-fx-background-color: #001f3f; -fx-text-fill: white;"); // Set background color to a nice
		// blue

		// Center the logo using HBox
		HBox logoPane = new HBox();
		logoPane.setAlignment(Pos.CENTER);
		HBox.setHgrow(logoPane, Priority.ALWAYS);

		// Add logo and slogan to the layout
		logoPane.getChildren().addAll(logoImageView);
		loginLayout.getChildren().addAll(sloganLabel, // Add the slogan above the logo
				titleLabel, // Add the title
				logoPane, // Add the health cross logo at the center
				createLabeledTextField("Username:", usernameField), createLabeledTextField("Password:", passwordField),
				rememberMeCheckbox, // Remember Me checkbox
				loginButton // Login button
		);

		Scene scene = new Scene(loginLayout, 500, 500); // Set the size of the scene
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	public HBox createLabeledTextField(String labelText, TextField textField) {
		Label label = new Label(labelText);
		label.setTextFill(Color.WHITE); // Set text color to white
		label.setFont(Font.font("Arial", 14));
		HBox labeledTextField = new HBox(20);
		labeledTextField.getChildren().addAll(label, textField);
		labeledTextField.setAlignment(Pos.CENTER);
		return labeledTextField;
	}
}
