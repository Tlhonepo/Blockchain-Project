public class UserData {
    private String id;
    private String gender;
    private String name;
    private String age;
    private String diagnosis;
    private String treatment;
    private String phoneNumber;
    private String height;
    private String weight;
    private String bloodType;
    private String allergies;
    private String bloodPressure;
    private String cholesterolLevel;
    private String date;

    public UserData(String id, String gender, String name, String age, String diagnosis, String treatment,
                    String phoneNumber, String height, String weight, String bloodType, String allergies,
                    String bloodPressure, String cholesterolLevel, String date) {
        this.id = id;
        this.gender = gender;
        this.name = name;
        this.age = age;
        this.diagnosis = diagnosis;
        this.treatment = treatment;
        this.phoneNumber = phoneNumber;
        this.height = height;
        this.weight = weight;
        this.bloodType = bloodType;
        this.allergies = allergies;
        this.bloodPressure = bloodPressure;
        this.cholesterolLevel = cholesterolLevel;
        this.date = date;
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getGender() {
        return gender;
    }

    public String getName() {
        return name;
    }

    public String getAge() {
        return age;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public String getTreatment() {
        return treatment;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getDate() {
        return date;
    }

    public String getHeight() {
        return height;
    }

    public String getWeight() {
        return weight;
    }

    public String getBloodType() {
        return bloodType;
    }

    public String getAllergies() {
        return allergies;
    }

    public String getBloodPressure() {
        return bloodPressure;
    }

    public String getCholesterolLevel() {
        return cholesterolLevel;
    }
}
