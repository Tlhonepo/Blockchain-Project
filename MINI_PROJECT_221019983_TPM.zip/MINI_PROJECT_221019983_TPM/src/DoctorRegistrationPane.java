import javafx.geometry.Insets;

import javafx.geometry.Pos;
import javafx.scene.control.*;

import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import acsse.csc03a3.Block;
import acsse.csc03a3.Blockchain;
import acsse.csc03a3.Transaction;

/*@author TP MANYANYE 
 * @author Student Number: 221019983
 */

public class DoctorRegistrationPane extends VBox {
    private Stage primaryStage;
    private Button btnRegister = new Button("Register");
    private Button btnBack = new Button("Back");
    private Label lblRegistration = new Label("Doctor Registration");
    private Label lblUsername = new Label("Username:");
    private Label lblEmailAddress = new Label("Email Address:");
    private Label lblDoctorQualification = new Label("Qualification:");
    private Label lblDoctorDescription = new Label("Description:");
    private Label lblDoctorAddress = new Label("Address:");
    private TextField txtUsername = new TextField();
    private TextField txtEmail = new TextField();
    private TextField txtQualification = new TextField();
    private TextField txtDescription = new TextField();
    private TextField txtAddress = new TextField();
    private Label lblRStatus = new Label("Status");
    private ImageView imageView = new ImageView("icon.jpg");
    
    //private List<Transaction<String>> transactions;
    private Blockchain<String> blockchain;
    String previousHashvalue;
    Block<String> block;
    private List<Transaction<String>> listtransaction = new ArrayList<>();
    
    
    Dashboard dboard = new Dashboard();

    public DoctorRegistrationPane(Stage primaryStage, Blockchain<String> blockchain) {
    	this.blockchain = blockchain;
        this.primaryStage = primaryStage;
        block = new Block<String>(previousHashvalue, listtransaction);
        setSpacing(10);
        setPadding(new Insets(10));

        btnRegister.setOnAction(e -> registerDoctor());
        Button btnBack = new Button("Back to Dashboard");
        btnBack.setOnAction(e -> {
            // Call the method to display the dashboard scene
        	dboard.dashboardScreen(primaryStage, blockchain);
        });
        imageView.setFitWidth(100);
        imageView.setFitHeight(100);

        StackPane imagePane = new StackPane(imageView);
        imagePane.setAlignment(Pos.TOP_LEFT);

        Button logoutButton = new Button("Logout");
        logoutButton.setOnAction(e -> {
            System.out.println("Logout action performed");
            primaryStage.close();
        });

        // Adding the italic line
        Label developerMessage = new Label("Page is for Developers and Authorized Med Practitioners");
        developerMessage.setStyle("-fx-font-style: italic;");

        HBox backButtonPane = new HBox(btnBack);
        backButtonPane.setAlignment(Pos.TOP_LEFT);
        backButtonPane.setPadding(new Insets(10, 0, 0, 10));

        getChildren().addAll(
                backButtonPane, imagePane, lblRegistration, lblUsername, txtUsername,
                lblEmailAddress, txtEmail, lblDoctorQualification,
                txtQualification, lblDoctorDescription, txtDescription,
                lblDoctorAddress, txtAddress, btnRegister, lblRStatus, logoutButton, developerMessage
        );

    }

    public void registerDoctor() {
        String username = txtUsername.getText();
        String emailAddress = txtEmail.getText();
        String qualification = txtQualification.getText();
        String description = txtDescription.getText();
        String address = txtAddress.getText();

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "root", "")) {
            String sql = "INSERT INTO authorized_doctors (Username, EmailAddress, Qualification, Description, Address) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, username);
                statement.setString(2, emailAddress);
                statement.setString(3, qualification);
                statement.setString(4, description);
                statement.setString(5, address);

                int rowsAffected = statement.executeUpdate();
                if (rowsAffected > 0) {
                    showConfirmationMessage("Doctor registration successful!");
                    // Clear fields after successful registration
                    txtUsername.clear();
                    txtEmail.clear();
                    txtQualification.clear();
                    txtDescription.clear();
                    txtAddress.clear();
                } else {
                    showAlert("Error", "Failed to register doctor.");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            showAlert("Error", "An error occurred while registering the doctor.");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showConfirmationMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Confirmation");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public boolean IdentifierCheck(String username) {
        for (Transaction<String> transaction : listtransaction) {
            if (transaction.getSender().equals(username)) {
                return true;
            }
        }
        return false;
    }


}
