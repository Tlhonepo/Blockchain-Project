import javafx.application.Application;

import javafx.stage.Stage;


import acsse.csc03a3.Blockchain;


 /*@author TP MANYANYE 
  * @author Student Number: 221019983
  */
public class Main extends Application {
	@SuppressWarnings("unused")
	private Blockchain blockchain = new Blockchain<>();
	
    public static void main(String[] args) {
        launch(args);
    }
  
    @Override
    public void start(Stage primaryStage) throws Exception {
    	Blockchain<String> blockchain = new Blockchain<>();
      
		RegistrationPane registrationPane = new RegistrationPane(primaryStage, blockchain);
        registrationPane.registrationScreen(); // Show registration screen first
    }
}
